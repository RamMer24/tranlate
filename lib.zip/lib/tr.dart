import 'package:flutter/material.dart';

class tr extends StatefulWidget {
  const tr({super.key});

  @override
  State<tr> createState() => _trState();
}

class _trState extends State<tr> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Text("heloo"),
    );
  }
}
